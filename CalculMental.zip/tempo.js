var tempo;
var mychron;
bon=0;
var pair=0;
var imago;
 var longu;
clique=-1;
var ancx=-10;
var ancy=-10;
atps=10;
var anclic=-1;
function affiche()
{
//bonnom=document.getElementById('tire').value;
//bonetat=document.getElementById('etat').value;
alert("La r�ponse �tait "+result);
//document.getElementById('zona').innerHTML="La r�ponse �tait "+result;
//document.getElementById('zona').style.visibility='visible';
}

function chanjou(id){
 if(id==1){atps=0;
//document.getElementById('alma').src='Cherokee.gif';document.getElementById('avion').innerHTML='Cherokee6';
document.getElementById('coeur').style.top=300;}
if(id==2){atps=1;
//document.getElementById('alma').src='MH1521.gif';document.getElementById('avion').innerHTML='MH 1521';
document.getElementById('coeur').style.top=340;}
if(id==3){atps=2;
//document.getElementById('alma').src='Cessna2.gif';document.getElementById('avion').innerHTML='CESSNA 206';
document.getElementById('coeur').style.top=380;}
if(id==4){atps=5;
//document.getElementById('alma').src='F104.gif';document.getElementById('avion').innerHTML='Lockheed F104';
document.getElementById('coeur').style.top=420;}
if(id==5){atps=10;
//document.getElementById('alma').src='F18.gif';document.getElementById('avion').innerHTML='F18 Hornet';
document.getElementById('coeur').style.top=460;}
}

function declenche(){
tempo=setTimeout("declenche()",500);
decomptetps();
}
function decomptetps(){
//atps=document.getElementById('maliste').value;
qq=document.getElementById("butt");
llz=parseInt(qq.style.width);
qq.style.width = (llz-atps)+"px";
if (llz<10) 
{
clearTimeout(tempo); 
affiche();
clearTimeout(mychron);
qq.style.width=500; 
if (parties<11)document.getElementById('fleche').style.visibility='visible';
if (parties<11) document.getElementById('calc').style.visibility='visible';
//mychron=setTimeout("lanza()",500)  
}

                         }








